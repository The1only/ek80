Simrad EK80 echosounder python interface module. 

The t9ek80.py should normally not be modified, it contains the generic interface. 

The biomass and singletargetchirp are example user files. 
The xml files ar config files. 

Usage: python3 biomass.py config2.xml 

The Simrad EK80 user manual can be found at: 
https://www.simrad.online/ek80/ref_en/default.htm
